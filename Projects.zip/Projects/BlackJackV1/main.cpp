
/* 
 * File:   main.cpp
 * Author: Jazmine Garcia
 * Created on July 20, at 3:03 PM
 * Purpose Project 1 First Version
 */

#include <iostream>
#include <cstdlib>
#include <ctime>
#include <cmath>
#include <iomanip>

using namespace std;

// Constants
const float INITIAL_MONEY = 1000.0; // Default initial money
const float MIN_BET = 0.01; // Minimum bet amount

int main() {
    srand(static_cast<unsigned int>(time(0)));

    float playerMoney = INITIAL_MONEY;
    float betAmount;
    string playerName;
    char playAgain;
    int gamesPlayed = 0;

    // Get player's name
    cout << "Enter your name: ";
    cin >> playerName;

    cout << "Welcome to Blackjack, " << playerName << "!" << endl;
    cout << "Starting money: $" << fixed << setprecision(2) << playerMoney << endl;

    bool continuePlaying = true;

    do {
        if (playerMoney <= 0) {
            cout << "You have no money left to bet. Game over!" << endl;
            continuePlaying = false;
            continue;
        }

        // Get and validate the player's bet amount
        cout << "You have $" << fixed << setprecision(2) << playerMoney << ". Enter your bet amount: $";
        cin >> betAmount;

        while (betAmount <= 0 || betAmount > playerMoney) {
            cout << "Invalid bet amount. Please enter an amount greater than $0.00 and not exceeding $" << fixed << setprecision(2) << playerMoney << ": ";
            cin >> betAmount;
        }

        // Display the bet amount as an integer
        int betAmountInt = static_cast<int>(betAmount);
        cout << "You have bet $" << betAmountInt << "." << endl;

        
        // Deal cards
        int playerCard1 = (rand() % 13) + 1;
        int playerCard2 = (rand() % 13) + 1;
        int dealerCard1 = (rand() % 13) + 1;
        int dealerCard2 = (rand() % 13) + 1;

        playerCard1 = (playerCard1 > 10) ? 10 : playerCard1;
        playerCard2 = (playerCard2 > 10) ? 10 : playerCard2;
        dealerCard1 = (dealerCard1 > 10) ? 10 : dealerCard1;
        dealerCard2 = (dealerCard2 > 10) ? 10 : dealerCard2;

        playerCard1 = (playerCard1 == 1) ? 11 : playerCard1;
        playerCard2 = (playerCard2 == 1) ? 11 : playerCard2;
        dealerCard1 = (dealerCard1 == 1) ? 11 : dealerCard1;
        dealerCard2 = (dealerCard2 == 1) ? 11 : dealerCard2;

        int playerTotal = playerCard1 + playerCard2;
        int dealerTotal = dealerCard1 + dealerCard2;
        char choice;
        bool playerBust = false;

        // Display initial hands
        cout << "Your cards: " << playerCard1 << " and " << playerCard2 << " (Total: " << playerTotal << ")" << endl;
        cout << "Dealer's face-up card: " << dealerCard1 << endl;

        // Player's turn
        while (!playerBust && playerTotal < 21) {
            cout << "Do you want to (h)it or (s)tand? ";
            cin >> choice;

            if (choice == 'h' || choice == 'H') {
                int newCard = (rand() % 13) + 1;
                newCard = (newCard > 10) ? 10 : newCard;
                newCard = (newCard == 1) ? 11 : newCard;
                playerTotal += newCard;
                cout << "You drew a " << newCard << ". Your total is now " << playerTotal << "." << endl;

                if (playerTotal > 21) {
                    cout << "You busted!" << endl;
                    playerBust = true;
                }
            } else if (choice == 's' || choice == 'S') {
                break;
            }
        }

        // Dealer's turn
        if (!playerBust) {
            cout << "Dealer's cards: " << dealerCard1 << " and " << dealerCard2 << " (Total: " << dealerTotal << ")" << endl;

            while (dealerTotal < 17) {
                int newCard = (rand() % 13) + 1;
                newCard = (newCard > 10) ? 10 : newCard;
                newCard = (newCard == 1) ? 11 : newCard;
                dealerTotal += newCard;
                cout << "Dealer draws a " << newCard << ". Dealer's total is now " << dealerTotal << "." << endl;
            }

            if (dealerTotal > 21) {
                cout << "Dealer busted! You win!" << endl;
                playerMoney += betAmount;
            } else if (dealerTotal > playerTotal) {
                cout << "Dealer wins with " << dealerTotal << ". You lose." << endl;
                playerMoney -= betAmount;
            } else if (dealerTotal < playerTotal) {
                cout << "You win with " << playerTotal << ", dealer has " << dealerTotal << "." << endl;
                playerMoney += betAmount;
            } else {
                cout << "It's a tie! Both you and the dealer have " << playerTotal << "." << endl;
            }
        } else {
            cout << "Dealer wins by default." << endl;
            playerMoney -= betAmount;
        }

        cout << "You now have $" << fixed << setprecision(2) << playerMoney << "." << endl;
        gamesPlayed++;
        cout << "Games played: " << gamesPlayed << "." << endl;

        // Ask if the player wants to play again
        if (playerMoney > 0) {
            cout << "Do you want to play again? (y/n): ";
            cin >> playAgain;
            continuePlaying = (playAgain == 'y');
        } else {
            continuePlaying = false;
        }
    } while (continuePlaying);

    if (playerMoney <= 0) {
        cout << "You have no money left to bet. Thank you for playing!" << endl;
    } else {
        cout << "Thank you for playing!" << endl;
    }

    return 0;
}