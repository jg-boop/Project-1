
/* 
 * File:   main.cpp
 * Author: Jazmine Garcia
 * Created on July 21, 2024, 10:24 AM
 * Purpose: 2nd Version of Project 1 
 */

#include <iostream>
#include <cstdlib>
#include <ctime>
#include <iomanip>

using namespace std;

int main() {
    // Constants
    const float INIT_MONEY = 1000.0; // Default initial money

    // Set the random number seed
    srand(static_cast<unsigned int>(time(0)));

    // Declare local variables
    float money = INIT_MONEY;
    float bet;
    string name;
    char again;
    int games = 0;

    // Get player's name
    cout << "Enter your name: ";
    cin >> name;

    cout << "Welcome to Blackjack, " << name << "!" << endl;
    cout << "Starting money: $" << fixed << setprecision(2) << money << endl;

    bool play = true;

    while (play) {
        if (money <= 0) {
            cout << "You have no money left to bet. Game over!" << endl;
            play = false;
            continue;
        }

        // Get and validate the player's bet amount
        cout << "You have $" << fixed << setprecision(2) << money << ". Enter your bet amount: $";
        cin >> bet;

        while (bet <= 0 || bet > money) {
            cout << "Invalid bet amount. Please enter an amount greater than $0.00 and not exceeding $" << fixed << setprecision(2) << money << ": ";
            cin >> bet;
        }

        // Display the bet amount as an integer
        int betInt = static_cast<int>(bet);
        cout << "You have bet $" << betInt << "." << endl;

        // Deal cards
        int pCard1 = (rand() % 13) + 1;
        int pCard2 = (rand() % 13) + 1;
        int dCard1 = (rand() % 13) + 1;
        int dCard2 = (rand() % 13) + 1;

        pCard1 = (pCard1 > 10) ? 10 : pCard1;
        pCard2 = (pCard2 > 10) ? 10 : pCard2;
        dCard1 = (dCard1 > 10) ? 10 : dCard1;
        dCard2 = (dCard2 > 10) ? 10 : dCard2;

        pCard1 = (pCard1 == 1) ? 11 : pCard1;
        pCard2 = (pCard2 == 1) ? 11 : pCard2;
        dCard1 = (dCard1 == 1) ? 11 : dCard1;
        dCard2 = (dCard2 == 1) ? 11 : dCard2;

        int pTotal = pCard1 + pCard2;
        int dTotal = dCard1 + dCard2;
        char choice;
        bool bust = false;

        // Display initial hands
        cout << "Your cards: " << pCard1 << " and " << pCard2 << " (Total: " << pTotal << ")" << endl;
        cout << "Dealer's face-up card: " << dCard1 << endl;

        // Player's turn
        bool playerDecided = false;
        while (!bust && !playerDecided) {
            cout << "Do you want to (h)it or (s)tand? ";
            cin >> choice;

            if (choice == 'h' || choice == 'H') {
                int newCard = (rand() % 13) + 1;
                newCard = (newCard > 10) ? 10 : newCard;
                newCard = (newCard == 1) ? 11 : newCard;
                pTotal += newCard;
                cout << "You drew a " << newCard << ". Your total is now " << pTotal << "." << endl;

                if (pTotal > 21) {
                    cout << "You busted!" << endl;
                    bust = true;
                }
            } else if (choice == 's' || choice == 'S') {
                playerDecided = true;
            } else {
                cout << "Invalid choice. Please enter 'h' to hit or 's' to stand." << endl;
            }
        }

        // Dealer's turn
        if (!bust) {
            cout << "Dealer's cards: " << dCard1 << " and " << dCard2 << " (Total: " << dTotal << ")" << endl;

            while (dTotal < 17) {
                int newCard = (rand() % 13) + 1;
                newCard = (newCard > 10) ? 10 : newCard;
                newCard = (newCard == 1) ? 11 : newCard;
                dTotal += newCard;
                cout << "Dealer draws a " << newCard << ". Dealer's total is now " << dTotal << "." << endl;
            }

            if (dTotal > 21) {
                cout << "Dealer busted! You win!" << endl;
                money += bet;
            } else if (dTotal > pTotal) {
                cout << "Dealer wins with " << dTotal << ". You lose." << endl;
                money -= bet;
            } else if (dTotal < pTotal) {
                cout << "You win with " << pTotal << ", dealer has " << dTotal << "." << endl;
                money += bet;
            } else {
                cout << "It's a tie! Both you and the dealer have " << pTotal << "." << endl;
            }
        } else {
            cout << "Dealer wins by default." << endl;
            money -= bet;
        }

        cout << "You now have $" << fixed << setprecision(2) << money << "." << endl;
        games++;
        cout << "Games played: " << games << "." << endl;

        // Ask if the player wants to play again
        if (money > 0) {
            cout << "Do you want to play again? (y/n): ";
            cin >> again;
            play = (again == 'y');
        } else {
            play = false;
        }
    }

    if (money <= 0) {
        cout << "You have no money left to bet. Thank you for playing!" << endl;
    } else {
        cout << "Thank you for playing!" << endl;
    }

    return 0;
}